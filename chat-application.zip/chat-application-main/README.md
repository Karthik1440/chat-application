# simple room chat application

## how to use this
```
git clone <url>
cd <folder name>
npm i
node index.js
```
